const isBinanceDomain = /\.?binance\.com$/i.test(location.hostname);
const isAlphaTokenPath = /^\/[^/]+\/alpha\/[^/]+\/[^/]+(?:\/|$)/.test(location.pathname);

if (!(location.protocol.startsWith('http') && isBinanceDomain && isAlphaTokenPath)) {
  console.log("[AutoAlpha] Not a binance alpha token page — script inert.", {
    protocol: location.protocol,
    hostname: location.hostname,
    pathname: location.pathname
  });
} else {
  // ---------- State ----------
  const STATE = {
    autoLimitTotalSell: false,
    totalOffset: 0,
    autoBuyOffset: false,
    buyOffset: 1,
    autoSellOffset: false,
    sellOffset: 1,
    autoConfirm: false,
    autoMinField: false,
    minFieldValue: ""
  };

  let STOPPED = false;

  function originKey() { return location.origin; }

  function applySavedState(s) {
    if (STOPPED) return; // khi đã stop, không tự start lại

    STATE.autoLimitTotalSell = !!s.autoLimitTotalSell;
    STATE.totalOffset = Number(s?.totalOffset ?? 0) || 0;

    STATE.autoBuyOffset = !!s.autoBuyOffset;
    STATE.buyOffset = Number(s?.buyOffset || 1) || 1;

    STATE.autoSellOffset = !!s.autoSellOffset;
    STATE.sellOffset = Number(s?.sellOffset || 1) || 1;

    STATE.autoConfirm = !!s.autoConfirm;
    STATE.autoMinField = !!s?.autoMinField;
    STATE.minFieldValue = s?.minFieldValue || "";

    // (Re)start theo flags
    startSell(); // limitTotal có thể chạy độc lập
    STATE.autoConfirm ? startActionClick() : stopActionClick();

    // Volume: chỉ event-driven
    STATE.autoMinField ? startMin() : stopMin();

    if (STATE.autoBuyOffset || STATE.autoSellOffset || STATE.autoMinField) {
      startPriceWatcher();
    } else {
      stopPriceWatcher();
    }
  }

  function loadStateForOrigin() {
    chrome.storage.local.get([originKey()], (res) => {
      const st = res[originKey()];
      if (!st) return; // không có cấu hình => không auto-start
      applySavedState(st || {});
    });
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    const key = originKey();
    if (!changes[key]) return;
    const newVal = changes[key].newValue;
    if (!newVal) {
      // bị remove (Stop & Clear)
      hardStop();
      return;
    }
    applySavedState(newVal || {});
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.origin && msg.origin !== originKey()) return;
    if (msg.type === "APPLY_ALL" || msg.type === "SYNC_STATE") {
      applySavedState(msg.state || {});
    } else if (msg.type === "STOP") {
      hardStop();
    }
  });

  // ---------- Helpers ----------
  function getElementByXpath(path) {
    return document.evaluate(path, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
  }

  function parseLocaleNumber(str) {
    if (!str) return NaN;
    str = String(str).trim();
    const hasDot = str.includes('.');
    const hasComma = str.includes(',');
    if (hasDot && hasComma) {
      const lastDot = str.lastIndexOf('.');
      const lastComma = str.lastIndexOf(',');
      const decimalSep = (lastDot > lastComma) ? '.' : ',';
      if (decimalSep === '.') {
        str = str.replace(/,/g, '');
      } else {
        str = str.replace(/\./g, '').replace(',', '.');
      }
    } else if (hasComma && !hasDot) {
      str = str.replace(',', '.');
    }
    str = str.replace(/[^\d.]/g, '');
    const n = parseFloat(str);
    return Number.isFinite(n) ? n : NaN;
  }

  function formatNumberForRef(num, refSample) {
    if (!Number.isFinite(num)) return '';
    const useComma = !!(refSample && refSample.includes(','));
    let decimals = 8;
    if (refSample) {
      const m = refSample.match(/[.,](\d+)/);
      if (m) decimals = Math.min(8, m[1].length);
    }
    let s = num.toFixed(decimals);
    if (s.startsWith('.')) s = '0' + s;
    if (s.startsWith('-.')) s = '-0' + s.slice(1);
    if (useComma) s = s.replace('.', ',');
    return s;
  }

  function setInputValue(el, val) {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
    if (!setter || !el) return;
    if (el.value === val) return;
    setter.call(el, val);
    try { el.setAttribute("value", val); } catch (e) { }
    el.dispatchEvent(new InputEvent("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function parseNumber(raw) { if (!raw) return NaN; return parseLocaleNumber(raw); }
  function formatLike(rawRef, num) { const ref = rawRef || ''; return formatNumberForRef(num, ref); }

  // ---------- LimitTotal logic ----------
  let sellTimer = null;
  let lastBuySourcePrice = null;

  function tickSell() {
    if (STOPPED) return;
    const priceInput = document.querySelector("#limitPrice");
    const totalSell = document.querySelector('#limitTotal[placeholder="Lệnh bán giới hạn"]');
    if (!priceInput || !totalSell) return;

    const raw = priceInput.value ?? "";
    const parsedPrice = parseNumber(raw);
    if (!Number.isFinite(parsedPrice)) return;

    const totalOff = Number(STATE.totalOffset ?? 0);
    const sourceForTotal = (Number.isFinite(lastBuySourcePrice)) ? lastBuySourcePrice : parsedPrice;

    const outNum = STATE.autoLimitTotalSell
      ? (totalOff >= 1 ? (sourceForTotal - totalOff * 1e-8) : sourceForTotal)
      : parsedPrice;

    const out = formatLike(raw, outNum);
    setInputValue(totalSell, out);
  }

  function startSell() {
    if (STOPPED) return;
    if (sellTimer) return;
    sellTimer = setInterval(tickSell, 120);
    tickSell();
    console.log("[Set rule Lệnh bán giới hạn] Timer ON");
  }
  function stopSell() {
    if (!sellTimer) return;
    clearInterval(sellTimer);
    sellTimer = null;
    console.log("[Set rule Lệnh bán giới hạn] Timer OFF");
  }

  // ---------- Auto click ----------
  let actionTimer = null;
  const XPATH_CONFIRM = "//button[normalize-space(.)='Xác nhận']";
  const XPATH_TIEP_TUC = "//button[normalize-space(.)='Tiếp tục']";
  let lastActionClickAt = 0;
  const ACTION_CLICK_COOLDOWN_MS = 150;
  const ACTION_POLL_INTERVAL_MS = 100;

  function isBuyTabActive() {
    return !!document.querySelector('.bn-tab.bn-tab__buySell.active[aria-controls="bn-tab-pane-0"]');
  }
  function isSellTabActive() {
    return !!document.querySelector('.bn-tab.bn-tab__buySell.active[aria-controls="bn-tab-pane-1"]');
  }

  function tickActionClick() {
    if (STOPPED) return;
    if (!STATE.autoConfirm) return;
    const now = Date.now();

    if (isBuyTabActive()) {
      const btn = getElementByXpath(XPATH_CONFIRM);
      if (btn && now - lastActionClickAt > ACTION_CLICK_COOLDOWN_MS) {
        btn.click();
        lastActionClickAt = now;
        console.log("[ActionClick] clicked 'Xác nhận'");
      }
      return;
    }

    if (isSellTabActive()) {
      const btn = getElementByXpath(XPATH_TIEP_TUC);
      if (btn && now - lastActionClickAt > ACTION_CLICK_COOLDOWN_MS) {
        btn.click();
        lastActionClickAt = now;
        console.log("[ActionClick] clicked 'Tiếp tục'");
      }
      return;
    }
  }

  function startActionClick() {
    if (STOPPED) return;
    if (actionTimer) return;
    actionTimer = setInterval(tickActionClick, ACTION_POLL_INTERVAL_MS);
    tickActionClick();
    console.log("[ActionClick] ON (", ACTION_POLL_INTERVAL_MS, "ms )");
  }
  function stopActionClick() {
    if (!actionTimer) return;
    clearInterval(actionTimer);
    actionTimer = null;
    console.log("[ActionClick] OFF");
  }

  // ---------- Volume (event-driven) ----------
  let minTimer = null; // giữ để tương thích
  function extractAvailableValueRaw() {
    const containers = document.querySelectorAll(".bn-flex.text-TertiaryText.items-center.justify-between.w-full");
    for (const c of containers) {
      if ((c.textContent || "").includes("Khả dụng")) {
        const valueNode = c.querySelector(".text-PrimaryText");
        if (!valueNode) continue;
        const text = valueNode.textContent.trim();
        const match = text.match(/[\d.,]+/);
        if (match) return match[0];
      }
    }
    return "";
  }

  function startMin() {
    console.log("[Set volume giao dịch] ON (event-driven by price changes)");
  }
  function stopMin() {
    if (minTimer) { clearInterval(minTimer); minTimer = null; }
    console.log("[Set volume giao dịch] OFF (no polling)");
  }

  // ---------- Price watcher ----------
  let priceWatcherTimer = null;
  let observedPriceEl = null;
  let suppressSet = false;
  let lastSeenValue = null;          // giá adjusted gần nhất
  let lastAdjustedValue = null;
  let lastAppliedSourceValue = null;

  function applyRuleAndRecordSource(el, sourceRaw) {
    if (STOPPED) return;

    const price = parseNumber(sourceRaw);
    if (!Number.isFinite(price) || price <= 0) return;

    const buyOff = Math.max(1, Number(STATE.buyOffset || 1));
    const sellOff = Math.max(1, Number(STATE.sellOffset || 1));
    const totalOff = Number(STATE.totalOffset ?? 0);

    // limitPrice theo flag & tab
    let desiredNum;
    if (isBuyTabActive() && STATE.autoBuyOffset) {
      desiredNum = price + buyOff * 1e-8;
    } else if (isSellTabActive() && STATE.autoSellOffset) {
      desiredNum = price - sellOff * 1e-8;
    } else {
      desiredNum = price;
    }

    const out = formatLike(sourceRaw, desiredNum);

    // set price input (đánh dấu suppress để phân biệt sự kiện do script)
    suppressSet = true;
    // ★ nếu exchange còn đang set giá trong cùng tick, ta đẩy về frame sau để “ghi đè cuối”
    requestAnimationFrame(() => {
      setInputValue(el, out);
      setTimeout(() => { suppressSet = false; }, 200);
    });

    // Nếu Buy active & limitTotal bật: set limitTotal ngay theo totalOff
    if (isBuyTabActive() && STATE.autoLimitTotalSell) {
      lastBuySourcePrice = price;
      const totalEl = document.querySelector('#limitTotal[placeholder="Lệnh bán giới hạn"]');
      if (totalEl) {
        const totalNum = totalOff >= 1 ? (price - totalOff * 1e-8) : price;
        const totalOut = formatLike(sourceRaw, totalNum);
        setInputValue(totalEl, totalOut);
      }
    }

    // Volume chỉ cập nhật khi giá thay đổi & autoMinField bật
    if (STATE.autoMinField) {
      if (isBuyTabActive()) {
        const inputBuy = document.querySelector('#limitTotal[placeholder="Tối thiểu 0,1"]');
        const rawUser = (STATE.minFieldValue || '').trim();
        if (inputBuy && rawUser) {
          const numBuy = parseLocaleNumber(rawUser);
          if (Number.isFinite(numBuy)) {
            const outBuy = formatNumberForRef(numBuy, el.value || inputBuy.value || '');
            setInputValue(inputBuy, outBuy);
          }
        }
      } else if (isSellTabActive()) {
        const inputSell = document.querySelector('#limitAmount');
        const rawAvail = extractAvailableValueRaw();
        if (inputSell && rawAvail) {
          const numSell = parseLocaleNumber(rawAvail);
          if (Number.isFinite(numSell)) {
            const outSell = formatNumberForRef(numSell, el.value || inputSell.value || '');
            setInputValue(inputSell, outSell);
          }
        }
      }
    }

    lastSeenValue = out;
    lastAdjustedValue = out;
    lastAppliedSourceValue = sourceRaw;
    console.log("[PriceWatcher] applied rule (source->adjusted). source=", sourceRaw, " adjusted=", out);
  }

  function ensureObservedPriceEl() {
    const el = document.querySelector("#limitPrice");
    if (!el) return null;
    if (observedPriceEl !== el) {
      try { if (observedPriceEl) observedPriceEl.removeEventListener("input", onPriceInput); } catch (e) { }
      observedPriceEl = el;
      observedPriceEl.addEventListener("input", onPriceInput, { passive: true });
      lastSeenValue = el.value ?? null;
      lastAdjustedValue = lastSeenValue;
      lastAppliedSourceValue = null;
    }
    return observedPriceEl;
  }

  function onPriceInput(e) {
    if (STOPPED) return;
    if (suppressSet) return; // bỏ qua sự kiện tự gây ra bởi script

    const el = e.target;
    if (!el) return;
    const cur = el.value ?? '';

    // Luôn áp dụng rule khi có input từ ngoài,
    // ngay cả khi cur === lastSeenValue (trường hợp user chọn giá trùng)
    if (!isBuyTabActive() && !isSellTabActive()) {
      lastSeenValue = cur;
      return;
    }
    applyRuleAndRecordSource(el, cur);
  }

  // ★★★★★ User-gesture hook: ép áp dụng rule kể cả khi giá không đổi
  let lastGestureAt = 0;
  const GESTURE_DEBOUNCE_MS = 120;

  function forceApplyOnGesture() {
    if (STOPPED) return;
    const now = Date.now();
    if (now - lastGestureAt < GESTURE_DEBOUNCE_MS) return;
    lastGestureAt = now;

    const el = ensureObservedPriceEl();
    if (!el) return;

    // Chỉ khi đang ở Buy/Sell và có bật offset/min
    if (!(isBuyTabActive() || isSellTabActive())) return;
    if (!(STATE.autoBuyOffset || STATE.autoSellOffset || STATE.autoMinField)) return;

    const cur = el.value ?? '';
    if (!cur) return;

    // Áp dụng rule **dù cur trùng lastSeenValue**
    applyRuleAndRecordSource(el, cur);
  }

  function startGestureHooks() {
    // click (bao gồm click orderbook), keydown Enter/Space
    document.addEventListener('click', forceApplyOnGesture, true);
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') forceApplyOnGesture();
    }, true);
  }
  function stopGestureHooks() {
    document.removeEventListener('click', forceApplyOnGesture, true);
    // keydown listener ẩn danh ở trên — để đơn giản không tháo (an toàn vì script stop ít xảy ra)
  }

  function startPriceWatcher() {
    if (STOPPED) return;
    if (priceWatcherTimer) return;

    startGestureHooks(); // ★ bật gesture hooks

    priceWatcherTimer = setInterval(() => {
      try {
        if (STOPPED) return;
        const el = ensureObservedPriceEl();
        if (!el) {
          lastSeenValue = null;
          lastAdjustedValue = null;
          lastAppliedSourceValue = null;
          lastBuySourcePrice = null;
          return;
        }
        if (!isBuyTabActive() && !isSellTabActive()) {
          lastSeenValue = el.value ?? lastSeenValue;
          return;
        }
        const cur = el.value ?? '';
        if (suppressSet) return;

        // Polling chỉ xử lý khi thấy giá đổi khác adjusted đã biết
        if (cur === lastSeenValue) return;

        applyRuleAndRecordSource(el, cur);
      } catch (err) {
        console.warn("[PriceWatcher] poll error", err);
      }
    }, 300);

    const existing = document.querySelector("#limitPrice");
    if (existing) {
      observedPriceEl = existing;
      observedPriceEl.addEventListener("input", onPriceInput, { passive: true });
      lastSeenValue = existing.value ?? null;
      lastAdjustedValue = lastSeenValue;
      const cur = existing.value ?? '';
      try {
        const price = parseNumber(cur);
        if (
          Number.isFinite(price) && price > 0 &&
          (STATE.autoBuyOffset || STATE.autoSellOffset || STATE.autoMinField) &&
          (isBuyTabActive() || isSellTabActive())
        ) {
          // Áp dụng quy tắc ngay lần đầu nếu có cấu hình tự động
          applyRuleAndRecordSource(existing, cur);
        }
      } catch (e) { }
    }

    console.log("[PriceWatcher] started (restricted to /alpha/ token pages)");
  }

  function stopPriceWatcher() {
    if (priceWatcherTimer) { clearInterval(priceWatcherTimer); priceWatcherTimer = null; }
    try { if (observedPriceEl) observedPriceEl.removeEventListener("input", onPriceInput); } catch (e) { }
    observedPriceEl = null;
    suppressSet = false;
    lastSeenValue = null;
    lastAdjustedValue = null;
    lastAppliedSourceValue = null;
    lastBuySourcePrice = null;

    stopGestureHooks(); // ★ tắt gesture hooks

    console.log("[PriceWatcher] stopped");
  }

  // ---------- STOP ----------
  function hardStop() {
    STOPPED = true;
    stopActionClick();
    stopMin();
    stopPriceWatcher();
    stopSell();
    console.log("[AutoAlpha] HARD STOP — timers/listeners stopped and state cleared");
  }

  // ---------- Start ----------
  loadStateForOrigin();
}
